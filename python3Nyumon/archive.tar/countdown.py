def main():
    for countdown in 5, 4, 3, 2, 1, "hey!":
        print(countdown)

if __name__ == "__main__":
    main()
